package com.app.student.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Students;
import com.app.student.Exception.StudentException;
import com.app.student.Repository.StudentRepo;

@Service
public class AdminServiceImpl implements AdminService {
	

	
	@Autowired
	private StudentRepo studentRepo;

	@Override
	public String addStudent(StudentsDTO studentsDTO) throws StudentException {
		
		Students students = new Students();
		
		students.setName(studentsDTO.getName());
		students.setGender(studentsDTO.getGender());
		students.setDob(studentsDTO.getDob());
		students.setAddress(studentsDTO.getAddress());
		
		Students studentsAdd = studentRepo.save(students);
		return  "Student Added Successfully!! "+"\n" + " Student ID" + studentsAdd.getStudentid();
	}

	@Override
	public String addCourse(Integer studentid, StudentsDTO studentsDTO) throws StudentException {
	
		Optional<Students> studentCourse = studentRepo.findById(studentid);
		Students s = studentCourse.orElseThrow(()-> new StudentException("Service.STUDENT_NOT_FOUND"));
		s.setCourses(studentsDTO.getCourses());
		return "Courses Added Successfully!!";
	}

	@Override
	public List<Students> getByName(String name) throws StudentException {
		List<Students> student = studentRepo.getByName(name);
		return student;
	}

}
