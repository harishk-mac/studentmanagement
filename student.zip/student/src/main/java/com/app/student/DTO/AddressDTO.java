package com.app.student.DTO;

public class AddressDTO {

	private Integer addressid;
	private String area;
	private String state;
	private String district;
	private Integer picode;
	private String addresstype;
	public Integer getAddressid() {
		return addressid;
	}
	public void setAddressid(Integer addressid) {
		this.addressid = addressid;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public Integer getPicode() {
		return picode;
	}
	public void setPicode(Integer picode) {
		this.picode = picode;
	}
	public String getAddresstype() {
		return addresstype;
	}
	public void setAddresstype(String addresstype) {
		this.addresstype = addresstype;
	}
	@Override
	public String toString() {
		return "AddressDTO [addressid=" + addressid + ", area=" + area + ", state=" + state + ", district=" + district
				+ ", picode=" + picode + ", addresstype=" + addresstype + "]";
	}
	
}
