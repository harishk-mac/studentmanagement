package com.app.student.Entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "students")
public class Students {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@SequenceGenerator(name="studentid" , sequenceName = "students" , initialValue = 1 , allocationSize = 1)
	@Column(name = "studentid" , length = 10)
	private Integer studentid;
	
	@Column(name="name" , length = 40)
	private String name;
	
	@Column(name = "date_of_birth")
	private LocalDate dob;
	
	@Column(name="gender" , length = 10)
	private String gender;
	
	@Column(name="email" , length = 40)
	private String email;
	
	@Column(name="number" , length = 40)
	private Integer number;
	
	@Column(name="father" , length = 40)
	private String father;
	
	@Column(name="mother" , length = 40)
	private String mother;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Address> address;
	
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Courses> courses;
	
	public Students() {
		// TODO Auto-generated constructor stub
	}

	public Integer getStudentid() {
		return studentid;
	}

	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getFather() {
		return father;
	}

	public void setFather(String father) {
		this.father = father;
	}

	public String getMother() {
		return mother;
	}

	public void setMother(String mother) {
		this.mother = mother;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public List<Courses> getCourses() {
		return courses;
	}

	public void setCourses(List<Courses> courses) {
		this.courses = courses;
	}

	@Override
	public String toString() {
		return "Students [studentid=" + studentid + ", name=" + name + ", dob=" + dob + ", gender=" + gender
				+ ", email=" + email + ", number=" + number + ", father=" + father + ", mother=" + mother + ", address="
				+ address + ", courses=" + courses + "]";
	}

	public Students(Integer studentid, String name, LocalDate dob, String gender, String email, Integer number,
			String father, String mother, List<Address> address, List<Courses> courses) {
		super();
		this.studentid = studentid;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.email = email;
		this.number = number;
		this.father = father;
		this.mother = mother;
		this.address = address;
		this.courses = courses;
	}
	
	
	
}
