package com.app.student.Service;

import java.util.List;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Students;
import com.app.student.Exception.StudentException;

public interface AdminService {
	
	public String addStudent (StudentsDTO studentsDTO) throws StudentException;
	
	public String addCourse (Integer studentid , StudentsDTO studentsDTO) throws StudentException;
	
	public List<Students> getByName (String name) throws StudentException;
	

}
