package com.app.student.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@SequenceGenerator(name="addressid" , sequenceName = "address" , initialValue = 1 , allocationSize = 1)
	@Column(name = "addressid" , length = 10)
	private Integer addressid;
	
	@Column(name="area" , length = 40)
	private String area;
	
	@Column(name="state" , length = 40)
	private String state;
	
	@Column(name="district" , length = 40)
	private String district;
	
	@Column(name="picode" , length = 40)
	private Integer picode;
	
	@Column(name="addresstype" , length = 40)
	private String addresstype;

	public Address() {
		// TODO Auto-generated constructor stub
	}
	
	public Integer getAddressid() {
		return addressid;
	}

	public void setAddressid(Integer addressid) {
		this.addressid = addressid;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public Integer getPicode() {
		return picode;
	}

	public void setPicode(Integer picode) {
		this.picode = picode;
	}

	public String getAddresstype() {
		return addresstype;
	}

	public void setAddresstype(String addresstype) {
		this.addresstype = addresstype;
	}

	@Override
	public String toString() {
		return "Address [addressid=" + addressid + ", area=" + area + ", state=" + state + ", district=" + district
				+ ", picode=" + picode + ", addresstype=" + addresstype + "]";
	}

	public Address(Integer addressid, String area, String state, String district, Integer picode, String addresstype) {
		super();
		this.addressid = addressid;
		this.area = area;
		this.state = state;
		this.district = district;
		this.picode = picode;
		this.addresstype = addresstype;
	}
	
	
}
