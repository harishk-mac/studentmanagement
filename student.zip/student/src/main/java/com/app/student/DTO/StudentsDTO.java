package com.app.student.DTO;

import java.time.LocalDate;
import java.util.List;

import com.app.student.Entity.Address;
import com.app.student.Entity.Courses;

public class StudentsDTO {
	
	private Integer studentid;
	private String name;
	private LocalDate dob;
	private String gender;
	private String email;
	private Integer number;
	private String father;
	private String mother;
	private List<Address> address;
	private List<Courses> courses;
	public Integer getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getFather() {
		return father;
	}
	public void setFather(String father) {
		this.father = father;
	}
	public String getMother() {
		return mother;
	}
	public void setMother(String mother) {
		this.mother = mother;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public List<Courses> getCourses() {
		return courses;
	}
	public void setCourses(List<Courses> courses) {
		this.courses = courses;
	}
	@Override
	public String toString() {
		return "StudentsDTO [studentid=" + studentid + ", name=" + name + ", dob=" + dob + ", gender=" + gender
				+ ", email=" + email + ", number=" + number + ", father=" + father + ", mother=" + mother + ", address="
				+ address + ", courses=" + courses + "]";
	}

}
