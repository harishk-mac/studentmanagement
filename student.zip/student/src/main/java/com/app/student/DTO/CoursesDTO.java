package com.app.student.DTO;

import java.util.List;

import com.app.student.Entity.Students;

public class CoursesDTO {
	
	private Integer coursesid;
	private String coursename;
	private String description;
	private String coursetype;
	private String courseduration;
	private String coursetopics;
	private List<Students> studentList;
	public Integer getCoursesid() {
		return coursesid;
	}
	public void setCoursesid(Integer coursesid) {
		this.coursesid = coursesid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCoursetype() {
		return coursetype;
	}
	public void setCoursetype(String coursetype) {
		this.coursetype = coursetype;
	}
	public String getCourseduration() {
		return courseduration;
	}
	public void setCourseduration(String courseduration) {
		this.courseduration = courseduration;
	}
	public String getCoursetopics() {
		return coursetopics;
	}
	public void setCoursetopics(String coursetopics) {
		this.coursetopics = coursetopics;
	}
	public List<Students> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}
	@Override
	public String toString() {
		return "CoursesDTO [coursesid=" + coursesid + ", coursename=" + coursename + ", description=" + description
				+ ", coursetype=" + coursetype + ", courseduration=" + courseduration + ", coursetopics=" + coursetopics
				+ ", studentList=" + studentList + "]";
	}
	
	

}
