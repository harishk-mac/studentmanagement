package com.app.student.Service;

import java.util.List;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Courses;
import com.app.student.Exception.StudentException;

public interface StudentsService {

	
	public List<Courses> getByCoursename(String coursename) throws StudentException;
	
	public String updateDetails(Integer studentid , String email ,String father , String mother ,Integer number , StudentsDTO studentsDTO) throws StudentException;
	
	public String leaveCourse (Integer studentid) throws StudentException;
	
}
