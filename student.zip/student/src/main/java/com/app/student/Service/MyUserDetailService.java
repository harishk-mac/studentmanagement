package com.app.student.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.student.Config.UserPrincipal;
import com.app.student.Entity.Admin;
import com.app.student.Repository.AdminRepo;

@Service
public class MyUserDetailService implements UserDetailsService{

	@Autowired
	public AdminRepo adminRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Admin admin = adminRepo.getByUsername(username);
		
		if(admin == null) {
			throw new UsernameNotFoundException("NOT_FOUND");
		}
		return new UserPrincipal(admin);
	}

	
}
