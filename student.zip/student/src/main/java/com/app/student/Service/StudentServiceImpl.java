package com.app.student.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Address;
import com.app.student.Entity.Courses;
import com.app.student.Entity.Students;
import com.app.student.Exception.StudentException;
import com.app.student.Repository.CourseRepo;
import com.app.student.Repository.StudentRepo;

@Service
public class StudentServiceImpl implements StudentsService {
	
	@Autowired
	private CourseRepo courseRepo;
	
	@Autowired
	private StudentRepo studentRepo;

	@Override
	public List<Courses> getByCoursename(String coursename) throws StudentException {
		List<Courses> course = courseRepo.getByCoursename(coursename);
		return course;
	}

	

	@Override
	public String leaveCourse(Integer studentid) throws StudentException {
		Optional<Students> student = studentRepo.findById(studentid);
		Students sid = student.orElseThrow( ()-> new StudentException("Service.STUDENT_NOT_FOUND"));
		studentRepo.deleteById(studentid);
		return "Student Deleted from Course";
	}



	@Override
	public String updateDetails(Integer studentid, String email, String father, String mother, Integer number,
			StudentsDTO studentsDTO) throws StudentException {
		Optional<Students> student = studentRepo.findById(studentid);
		Students sid = student.orElseThrow( ()-> new StudentException("Service.STUDENT_NOT_FOUND"));
		
		sid.setEmail(email);
		sid.setFather(father);
		sid.setMother(mother);
		sid.setNumber(number);
		sid.setAddress(studentsDTO.getAddress());
		
		return "Student Details Updated!!";
	
	}

	
	

}
