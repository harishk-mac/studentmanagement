package com.app.student.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.student.Entity.Courses;

@Repository
public interface CourseRepo extends JpaRepository<Courses, Integer>{

	@Query("SELECT c FROM Courses c WHERE c.coursename =:coursename")
	public List<Courses> getByCoursename(@Param("coursename") String coursename);
}
