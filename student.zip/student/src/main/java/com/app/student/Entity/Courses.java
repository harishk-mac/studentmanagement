package com.app.student.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "courses")
public class Courses {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@SequenceGenerator(name="coursesid" , sequenceName = "courses" , initialValue = 1 , allocationSize = 1)
	@Column(name = "coursesid" , length = 10)
	private Integer coursesid;
	
	@Column(name="coursename" , length = 10)
	private String coursename;
	
	@Column(name="description" , length = 100)
	private String description;
	
	@Column(name="coursetype" , length = 10)
	private String coursetype;

	@Column(name="courseduration" , length = 10)
	private String courseduration;

	@Column(name="coursetopics" , length = 10)
	private String coursetopics;
	
	@ManyToMany(mappedBy = "courses")
	@JsonBackReference
	private List<Students> studentList;
	
	 public Courses() {
		// TODO Auto-generated constructor stub
	}

	public Integer getCoursesid() {
		return coursesid;
	}

	public void setCoursesid(Integer coursesid) {
		this.coursesid = coursesid;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCoursetype() {
		return coursetype;
	}

	public void setCoursetype(String coursetype) {
		this.coursetype = coursetype;
	}

	public String getCourseduration() {
		return courseduration;
	}

	public void setCourseduration(String courseduration) {
		this.courseduration = courseduration;
	}

	public String getCoursetopics() {
		return coursetopics;
	}

	public void setCoursetopics(String coursetopics) {
		this.coursetopics = coursetopics;
	}

	public List<Students> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}

	@Override
	public String toString() {
		return "Courses [coursesid=" + coursesid + ", coursename=" + coursename + ", description=" + description
				+ ", coursetype=" + coursetype + ", courseduration=" + courseduration + ", coursetopics=" + coursetopics
				+ ", studentList=" + studentList + "]";
	}

	public Courses(Integer coursesid, String coursename, String description, String coursetype, String courseduration,
			String coursetopics, List<Students> studentList) {
		super();
		this.coursesid = coursesid;
		this.coursename = coursename;
		this.description = description;
		this.coursetype = coursetype;
		this.courseduration = courseduration;
		this.coursetopics = coursetopics;
		this.studentList = studentList;
	}
	
	
	
}
