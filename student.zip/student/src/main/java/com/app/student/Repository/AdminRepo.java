package com.app.student.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.student.Entity.Admin;

@Repository
public interface AdminRepo extends JpaRepository<Admin, Integer>{

	public Admin getByUsername(String username);
}
