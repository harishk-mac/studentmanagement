package com.app.student.API;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Students;
import com.app.student.Exception.StudentException;
import com.app.student.Service.AdminService;

@RestController
@RequestMapping(value="/admin")
public class AdminAPI {

	@Autowired
	private AdminService adminService;
	
	@PostMapping(value="/api/add")
	public ResponseEntity<String> addStudent (@RequestBody StudentsDTO studentsDTO) throws StudentException{
		String msg = adminService.addStudent(studentsDTO);
		return new ResponseEntity<>(msg,HttpStatus.CREATED);
	}
	
	@PutMapping(value="/addcourse/{studentid}")
	public ResponseEntity<String> addCourse(@PathVariable Integer studentid , StudentsDTO studentsDTO) throws StudentException{
		String msg = adminService.addCourse(studentid, studentsDTO);
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
	
	@GetMapping(value="/api/{name}")
	public ResponseEntity <List<Students>> getByName(@PathVariable String name) throws StudentException{
		List<Students> student = adminService.getByName(name);
		return new ResponseEntity<> (student,HttpStatus.ACCEPTED);
				
	}
}
