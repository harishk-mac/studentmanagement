package com.app.student.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.student.Entity.Students;

@Repository
public interface StudentRepo extends JpaRepository<Students, Integer> {
	
	@Query("SELECT s FROM Students c WHERE s.name =:name")
	public List<Students> getByName(@Param("name") String name);
}