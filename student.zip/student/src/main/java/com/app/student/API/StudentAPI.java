package com.app.student.API;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.student.DTO.StudentsDTO;
import com.app.student.Entity.Courses;
import com.app.student.Exception.StudentException;
import com.app.student.Service.StudentsService;

@RestController
@RequestMapping(value="/students")
public class StudentAPI {
	
	@Autowired
	private StudentsService studentsService;
	
	@GetMapping(value="/course/{coursename}")
	public ResponseEntity<List<Courses>> getByCoursename(@PathVariable String coursename) throws StudentException{
		List<Courses> studentCourseName = studentsService.getByCoursename(coursename);
		return new ResponseEntity<>(studentCourseName,HttpStatus.ACCEPTED);
	}

	@PutMapping(value="/update/{studentid}")
	public ResponseEntity<String> updateDetails(@PathVariable Integer studentid, @RequestBody StudentsDTO studentsDTO) throws StudentException{
		String msg = studentsService.updateDetails(studentid,studentsDTO.getEmail(),studentsDTO.getFather(),studentsDTO.getMother(),studentsDTO.getNumber(), studentsDTO);
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
	
	@DeleteMapping(value="/delete/{studentid}")
	public ResponseEntity<String> leaveCourse (@PathVariable Integer studentid) throws StudentException{
		String msg = studentsService.leaveCourse(studentid);
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
}
